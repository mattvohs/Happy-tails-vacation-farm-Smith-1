import React from 'react';

function App() {
  return (
    <div>
      <nav>
        <a href="#">Home</a>
        <a href="#">About</a>
        <a href="#">Pricing</a>
        <a href="#">Contact</a>
      </nav>

      <header style={{
        backgroundColor: '#e3fcec',
        padding: '3rem',
        textAlign: 'center'
      }}>
        <h1 style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>Happy Tails Vacation Farm</h1>
        <p style={{ fontSize: '1.2rem' }}>
          A cozy countryside retreat just for small dogs.
        </p>
      </header>

      <section>
        <h2>About Us</h2>
        <p>
          Located on a peaceful farm surrounded by nature, Happy Tails provides a secure and playful
          environment where your dog feels like family. We specialize in personalized care for small breeds.
        </p>
      </section>

      <section>
        <h2>Pricing</h2>
        <ul>
          <li>Overnight Boarding: $45 per night</li>
          <li>Daycare: $30 per day</li>
          <li>Bath & Brush (optional): $20</li>
        </ul>
      </section>

      <section>
        <h2>Contact Us</h2>
        <p>Email: info@happytailsfarm.com</p>
        <p>Phone: (123) 456-7890</p>
        <form style={{ display: 'grid', gap: '1rem', marginTop: '1rem' }}>
          <input type="text" placeholder="Your Name" required />
          <input type="email" placeholder="Your Email" required />
          <textarea placeholder="Message" rows="4" />
          <button type="submit">Send Message</button>
        </form>
      </section>

      <footer>
        &copy; {new Date().getFullYear()} Happy Tails Vacation Farm. All rights reserved.
      </footer>
    </div>
  );
}

export default App;
